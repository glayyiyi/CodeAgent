const s="/document/assets/API的个人令牌-01c8b1a8.png";export{s as _};
