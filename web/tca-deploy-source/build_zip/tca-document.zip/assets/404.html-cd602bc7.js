import{_ as e,o as c,c as t}from"./app-765c7714.js";const _={};function o(r,n){return c(),t("div")}const a=e(_,[["render",o],["__file","404.html.vue"]]);export{a as default};
