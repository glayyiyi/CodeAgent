const o="/document/assets/manage_tool_01-90fd47ba.png";export{o as _};
